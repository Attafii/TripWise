-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: tripwise
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` varchar(32) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('68e65e6d-02be-11f1-86c8-70a8d35dce50','admin@tripwise.com','Admin User','ADMIN',1),('6e9cbf6b-0531-11f1-86c8-70a8d35dce50','new.user@tripwise.com','New User','USER',1),('a8c2b760-0537-11f1-86c8-70a8d35dce50','manager@tripwise.com','Manager User','MANAGER',1),('a8c2b8e5-0537-11f1-86c8-70a8d35dce50','user@tripwise.com','Normal User','USER',1),('a8c2d1c8-0537-11f1-86c8-70a8d35dce50','alex@tripwise.com','Alex Johnson','MANAGER',1),('a8c2d390-0537-11f1-86c8-70a8d35dce50','sara@tripwise.com','Sara Ahmed','USER',1),('a8c2d4c3-0537-11f1-86c8-70a8d35dce50','mohamed@tripwise.com','Mohamed Ali','USER',1),('a8c2d57b-0537-11f1-86c8-70a8d35dce50','ines@tripwise.com','Ines Gharbi','MANAGER',1),('a8c2d7f9-0537-11f1-86c8-70a8d35dce50','youssef@tripwise.com','Youssef Ben Sassi','USER',1),('a8c2d8a6-0537-11f1-86c8-70a8d35dce50','amel@tripwise.com','Amel Kallel','USER',0),('a8c2d9ca-0537-11f1-86c8-70a8d35dce50','rim@tripwise.com','Rim Chebbi','USER',1),('a8c2e437-0537-11f1-86c8-70a8d35dce50','hatem@tripwise.com','Hatem Krimi','USER',0),('a8c2e545-0537-11f1-86c8-70a8d35dce50','ahmed@tripwise.com','Ahmed Jalel','USER',1),('a8c2e5cc-0537-11f1-86c8-70a8d35dce50','salma@tripwise.com','Salma Kefi','USER',1),('a8c2e670-0537-11f1-86c8-70a8d35dce50','ons@tripwise.com','Ons Mejri','USER',1),('a8c2e71c-0537-11f1-86c8-70a8d35dce50','nour@tripwise.com','Nour Ayari','USER',1),('a8c2fbcc-0537-11f1-86c8-70a8d35dce50','houssem@tripwise.com','Houssem Saidi','USER',1),('a8c2fd33-0537-11f1-86c8-70a8d35dce50','fatma@tripwise.com','Fatma Ferchichi','MANAGER',1),('a8c2fdf5-0537-11f1-86c8-70a8d35dce50','walid@tripwise.com','Walid Mzoughi','USER',1),('a8c2fea1-0537-11f1-86c8-70a8d35dce50','saif@tripwise.com','Saif Rekik','USER',1),('a8c2ff3c-0537-11f1-86c8-70a8d35dce50','imen@tripwise.com','Imen Trabelsi','USER',0),('a8c2ffa3-0537-11f1-86c8-70a8d35dce50','habib@tripwise.com','Habib Bouhlel','USER',1),('a8c30021-0537-11f1-86c8-70a8d35dce50','amal@tripwise.com','Amal Chammakhi','USER',1),('a8c300a0-0537-11f1-86c8-70a8d35dce50','khalil@tripwise.com','Khalil Abid','USER',1),('a8c30109-0537-11f1-86c8-70a8d35dce50','rania@tripwise.com','Rania Maatoug','USER',1),('a8c3016c-0537-11f1-86c8-70a8d35dce50','rafik@tripwise.com','Rafik Mlayah','USER',1),('bcca0d7f-0371-11f1-86c8-70a8d35dce50','test@tripwise.com','Test User','USER',0),('e44b51ba-0373-11f1-86c8-70a8d35dce50','test2@tripwise.com','Test User','USER',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-14 12:00:46
